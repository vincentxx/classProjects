Name: VU TRAN
Student ID: 48894667
HW09 CS141

#To build and run the program: "make" or "make main"
#To clean the build: "make clean"
#If you want to re-run it: "make"

#Info
Requirements:
Java 1.8.0_111 or 1.8.0_181 (on openlab)
Using IDE Netbeans 8.2
Using Javafx for GUI
Tested run successfully on Ubuntu 18.04, x64.

